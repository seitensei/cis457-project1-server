package me.tnsi.jftp;

import java.io.*;
import java.net.*;
import java.util.*;

final class FtpRequest implements Runnable {
    final static String CRLF = "\r\n";
    Socket socket;
    int dataPort = 3716;

    // constructor
    public FtpRequest(Socket socket) throws Exception {
        this.socket = socket;
    }

    // runnable run
    public void run() {
        try {
            processRequest();
        } catch (Exception e) {
            System.out.println("IM HERE");
            System.out.println(e);
        }
    }

    private void processRequest() throws Exception {
        String commandExport = "";

        // output stream
        BufferedWriter os = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

        // input stream
        BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        //Ryan's Input Stream
        //DataInputStream rk = new DataInputStream(socket.getInputStream());

        // Send Welcome Response to Client
        response(os, "Response: 220 Welcome to JFTP." + CRLF);

        // command loop
        // reference: https://en.wikipedia.org/wiki/List_of_FTP_server_return_codes
        String commandRequest;
        while(true) {
            System.out.println("In the While Loop."); //my debug line -rk
            String commandLine = br.readLine(); //null pointer going here after quit. not sure if totally quitting enough.
            //byte[] result = new byte[10];
            //rk.read(result);
            //String commandLine = new String(result).trim();
            System.out.println(commandLine); //my debug line -rk

//            StringTokenizer tokens = new StringTokenizer(commandLine);
            String[] clientCommand = commandLine.split(" ");//tokens.nextToken();
//            System.out.println(clientCommand);

            //before getting to next token, we need to make sure that there is going to be a second token
            //before trying to use it.

            if(clientCommand.length == 1)
            {
                commandExport = clientCommand[0];
            }
            else{
                String clientArg = clientCommand[1];//tokens.nextToken();
                commandExport = clientCommand[0] + " " + clientArg;
            }

            //System.out.println(commandLine); //my debug line -rk

            if(clientCommand[0].equals("LIST")) {
                System.out.println("IN LIST");
                ServerSocket dataSock = new ServerSocket(dataPort);
                System.out.println(dataSock.isClosed());
                response(os, "Response: 225 Data Connection Open." + CRLF);
                System.out.println("SOCKET MADE");
                while(true) {
                    Socket dataConn = dataSock.accept();
                    System.out.println("SOCKET accepted.");

                    // Create Data Handler
                    DataRequest dataHandler = new DataRequest(dataConn, commandExport);

                    // Data handler Thread
                    Thread dThread = new Thread(dataHandler);

                    // run
                    dThread.run();
                    System.out.println("Thread running.");
                    dataSock.close(); //added to close things
                    break; //added to get us back to listening for other instructions.
                }
            }

            if(clientCommand[0].equals("RETR")) {
                response(os, "Response: 202 RETR not implemented." + CRLF);
            }

            if(clientCommand[0].equals("STOR")) {
                response(os, "Response: 202 STOR not implemented." + CRLF);
            }

            if(clientCommand[0].equals("QUIT")) {
                response(os, "Response: 221 Closing connection." + CRLF);
                break;
            }

        }

        //need to prevent null pointer exceptions from resulting in quit commands.
        System.out.println("---- Closing Connection ----");
        os.close();
        br.close();
        socket.close();
    }

    private void response(BufferedWriter os, String res) throws Exception {
        System.out.println(res);
        os.write(res, 0, res.length());
        os.write("\r\n", 0, "\r\n".length());
        os.flush();
    }

    private ArrayList<String> getDirectory() {
        ArrayList<String> listContents = new ArrayList<String>();

        File dir = new File("./data");
        File[] dirList = dir.listFiles();

        for (File file : dirList) {
            listContents.add(file.getName());
        }

        return listContents;
    }
}
