package me.tnsi.jftp;

import java.net.*;
import java.io.*;
import java.util.*;

public class DataRequest extends Thread{
    final static String CRLF = "\r\n";
    Socket socket;
    String command;

    public DataRequest(Socket socket, String command) throws Exception {
        this.socket = socket;
        this.command = command;
    }

    public void run() {
        try {
            processRequest();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void processRequest() throws Exception {
        // output stream
        DataOutputStream os = new DataOutputStream(socket.getOutputStream());
        DataInputStream  is = new DataInputStream(socket.getInputStream());

        if(command.equals("LIST")) {
            for(String s : getDirectory()) {
                os.writeBytes(s + CRLF);
                os.flush();
            }
            os.writeBytes("EOF" + CRLF);
            os.flush();
        }

        if(command.contains("RETR")) {
            String fileName = command.substring(5); //gets just the file name for our method to use.
            try {
               for (String lineContents : getFile(fileName)) {
                   os.writeUTF(lineContents);
                   os.flush();
               }
               os.writeUTF("EOF" + CRLF);
               os.flush();
            }
            catch(Exception e)
            {
               //response for a file not found error that would then be written out and the downloading of the file wouldn't happen on the
               //client end.
               os.writeBytes("Error: File Not Found" + CRLF);
               os.flush();
            }
        }

        if(command.contains("STOR")) {
            String fileName = command.substring(5); //gets just the file name for our method to use.
            try {
                //use the data input stream to write the lines from the client to the file here on the server.
                //will need a localized file output stream that is pointed at the file we are creating.
                BufferedWriter dataToFile = new BufferedWriter( new FileWriter(createFile(fileName)));
                String toWrite = "initializer";
                while(!(toWrite.equals("EOF\r\n"))){ //toWrite becomes EOF when the client sends EOF as the output at the end of the file reading on its end!!
                    toWrite = is.readUTF();
                    dataToFile.write(toWrite + CRLF); //need my own \r\n here or would the file itself take care of it?
                    dataToFile.flush(); //adding my own just in case.
                }
                dataToFile.close();
            }
            catch(Exception e)
            {
                //response for a file not found error that would then be written out and the downloading of the file wouldn't happen on the
                //client end.
                System.out.println("in store exception " + e.toString());
                os.writeBytes("Error: File Not created." + CRLF);
                os.flush();
            }
        }

        //all successful responses should be done within ftprequest so that they are sent out on the control connection.
        System.out.println("Closing up shop");
        is.close();
        os.close();
        socket.close();

    }

    private ArrayList<String> getDirectory() {
        ArrayList<String> listContents = new ArrayList<String>();

        File dir = new File("./data");
        File[] dirList = dir.listFiles();

        for (File file : dirList) {
            System.out.println(file.getName());
            listContents.add(file.getName());
        }

        return listContents;
    }

    private ArrayList<String> getFile(String fileName) throws Exception {
        ArrayList<String> export = new ArrayList<String>();
        File targetFile = new File("./data/" + fileName);
        BufferedReader fileReader = new BufferedReader(new FileReader(targetFile));
        String curLine;
        while ((curLine = fileReader.readLine()) != null) {
            export.add(curLine);
        }
        fileReader.close();
        return export;

        }

    private File createFile(String fileName){
        File newFile = new File("./data/" + fileName);
        return newFile;
    }
}
