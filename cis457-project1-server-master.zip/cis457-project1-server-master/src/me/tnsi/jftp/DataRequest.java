package me.tnsi.jftp;

import java.net.*;
import java.io.*;
import java.util.*;

public class DataRequest implements Runnable {
    final static String CRLF = "\r\n";
    Socket socket;
    String command;

    public DataRequest(Socket socket, String command) throws Exception {
        this.socket = socket;
        this.command = command;
    }

    public void run() {
        try {
            processRequest();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void processRequest() throws Exception {
        // output stream
        DataOutputStream os = new DataOutputStream(socket.getOutputStream());
        DataInputStream  is = new DataInputStream(socket.getInputStream());

        if(command.equals("LIST")) {
            for(String s : getDirectory()) {
                os.writeBytes(s + CRLF);
                os.flush();
            }
            os.writeBytes("EOF" + CRLF);
            os.flush();
        }

        if(command.contains("RETR")) {
            String fileName = command.substring(5); //gets just the file name for our method to use.
            try {
               for (String lineContents : getFile(fileName)) {
                   os.writeBytes(lineContents + CRLF);
                   os.flush();
               }
               os.writeBytes("EOF" + CRLF);
               os.flush();
            }
            catch(Exception e)
            {
               //response for a file not found error that would then be written out and the downloading of the file wouldn't happen on the
               //client end.
               os.writeBytes("Error: File Not Found" + CRLF);
               os.flush();
            }
        }

        if(command.contains("STOR")) {
            String fileName = command.substring(5); //gets just the file name for our method to use.
            try {
                //use the data input stream to write the lines from the client to the file here on the server.
                //will need a localized file output stream that is pointed at the file we are creating.
                BufferedWriter dataToFile = new BufferedWriter( new FileWriter(createFile(fileName)));
                String toWrite = "initializer";
                while(!(toWrite.equals("EOF"))){ //toWrite becomes EOF when the client sends EOF as the output at the end of the file reading on its end!!
                    toWrite = is.readUTF();
                    dataToFile.write(toWrite + CRLF); //need my own \r\n here or would the file itself take care of it?
                    dataToFile.flush(); //adding my own just in case.
                }
                dataToFile.close();
            }
            catch(Exception e)
            {
                //response for a file not found error that would then be written out and the downloading of the file wouldn't happen on the
                //client end.
                System.out.println("in store exception " + e.toString());
                os.writeBytes("Error: File Not created." + CRLF);
                os.flush();
            }
        }

        //all successful responses should be done within ftprequest so that they are sent out on the control connection.
        System.out.println("Closing up shop");
        is.close();
        os.close();
        socket.close();

    }

    private ArrayList<String> getDirectory() {
        ArrayList<String> listContents = new ArrayList<String>();

        File dir = new File("./data");
        File[] dirList = dir.listFiles();

        for (File file : dirList) {
            listContents.add(file.getName());
        }

        return listContents;
    }

    private ArrayList<String> getFile(String fileName) throws Exception{
        File wantedFile = new File("./data/" + fileName);
            //need file input stream/reader. use that in the while loop.
            BufferedReader dataIn = new BufferedReader(new FileReader(wantedFile));
            ArrayList<String> dataFromFile = new ArrayList<>();

            String lastString = "ping";
            while(true){ //scared to use this but it is what it is.
                try {
                    lastString = dataIn.readLine();
                    if(lastString.equals("null")){
                        break;
                    } else{
                        dataFromFile.add(lastString);
                    }
                } catch (EOFException F) {
                    break; //end of file reached, so we are done.
                }
                //use an end of file catch to break out maybe?
            } //maybe just use true and use an EOF exception to catch when we are done with the looping?

            return dataFromFile;
    }

    private File createFile(String fileName){
        File newFile = new File("./data/" + fileName);
        return newFile;
    }
}
