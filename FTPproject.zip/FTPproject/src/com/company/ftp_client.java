package com.company;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class ftp_client {

    static boolean loop = true;
    static boolean connected = false;
    static Socket controlConnection = new Socket();
    //static DataInputStream inputS = null;
    static BufferedReader inputS = null;
    //static DataOutputStream outputS = null;
    static BufferedWriter outputS = null;

    //String command = "";// = userInput.nextLine();
    static String[] commandsAndParams = null;

    public static void main(String[] args) {

        Scanner userInput = new Scanner(System.in);
        System.out.println("Welcome to the program, please connect to a server.");
        String command  = userInput.nextLine();
        commandsAndParams = command.split(" ");


            while (!connected) {
                    if(commandsAndParams.length == 2) {
                        if (commandsAndParams[0].equals("CONNECT")) {
                            //connect to the server via the provided IP and Port number
                            connected = connect(commandsAndParams[1], 3715);
                        }
                    }
                    else if(commandsAndParams.length == 3) {
                        if (commandsAndParams[0].equals("CONNECT")) {
                            //connect to the server via the provided IP
                            // and Port number
                            connected = connect( commandsAndParams[1],
                                    Integer.parseInt(commandsAndParams[2]));
                        }
                    }
                    else {
                        System.out.println("Please connect to a server before continuing this program." +
                                " We need the command CONNECT followed by a space, a valid IP address, " +
                                "and optionally a port number.");
                    }
                //end of while loop.
//                System.out.println("end of connected loop.");
//                System.out.println(connected);
            }


        while(loop) {
             System.out.println("Welcome to the program, specify a function with" +
                    " spaces separating the command and any potential parameters");
             command = userInput.nextLine();
             commandsAndParams = command.split(" ");

            try {
                if(commandsAndParams.length == 1){
                    if(commandsAndParams[0].equals("LIST")){
                        System.out.println("LIST RECEIVED");
                        outputS.flush();
                        outputS.write("LIST");
                        outputS.write("\r\n");
                        outputS.flush();

                        String resultString = "";
                        while(resultString.equals("")) {
                            resultString = inputS.readLine();
                        }

                        System.out.println(resultString);

                        if(resultString.equals("Response: 225 Data Connection Open.")){

                            Socket dataSocket = new Socket(controlConnection.getInetAddress(), 3716);

                            BufferedReader listInput = new BufferedReader(new InputStreamReader(dataSocket.getInputStream()));

                            //and do other logic listening for the list and processing it before printing it
                            ArrayList<String> ourFiles = new ArrayList<>();

                            String lastReceived = "Directory Contents(If all you see is \"End of the list function\", then the directory is empty.)";
                            System.out.println(lastReceived);
                            while(true) {
                                lastReceived = listInput.readLine();
                                //System.out.println(lastReceived);
                                if(lastReceived.equals("EOF")){
                                    break;
                                } else {
                                    ourFiles.add(lastReceived);
                                }
                            }

                            resultString = "";
                            while(resultString.equals("")) {
                                resultString = inputS.readLine();
                            }

                            //System.out.println("Waiting for a response: "+resultString);

                            if(resultString.equals("Response: 226 Closing data connection.")) {
                                for (String word : ourFiles) {
                                    System.out.println(word);
                                }

                                System.out.println("End of the list function");
                                listInput.close();
                                dataSocket.close();
                            }

                        } else{
                            System.out.println("Data Connection Refused");
                        }

                    }

                    if (commandsAndParams[0].equals("QUIT")) {
                        outputS.write("QUIT");
                        //might prevent null exceptions if we wait for the servers response before we ourselves close things.
                        outputS.close();
                        inputS.close();
                        controlConnection.close();
                        loop = false;
                    }

                } //end of if for handling one word commands

                if(commandsAndParams.length == 2) {
                    if (commandsAndParams[0].equals("RETR")) {
                        outputS.write("RETR " + commandsAndParams[1]);
                        outputS.write("\r\n");
                        outputS.flush();


                        String resultString = "";
                        while(resultString.equals("")) {
                            resultString = inputS.readLine();
                        }

                        System.out.println(resultString);

                        if(resultString.equals("Response: 225 Data Connection Open.")) {
                            Socket dataSocket = new Socket(controlConnection.getInetAddress(), 3716);
                            DataInputStream serverInput = new DataInputStream(dataSocket.getInputStream());

//                            resultString = "";
//                            while (resultString.equals("")) {
//                                resultString = inputS.readLine();
//                            }
//
//                            if (resultString.equals("Response: 225 Data Connection Open.\r\n\r\n")) {
                                File ourFile = new File(commandsAndParams[1]);
                                BufferedWriter dataOutToFile = new BufferedWriter(new FileWriter(ourFile));
                                String readLine = "ping";
                                while (true) {
                                    System.out.println("Tried to read.");
                                    readLine = serverInput.readUTF();
                                    if (!readLine.equals("EOF\r\n")) {
                                        dataOutToFile.write(readLine);
                                        dataOutToFile.flush();
                                    } else {
                                        break;
                                    }
                                }

                                resultString = "";
                                while (resultString.equals("")) {
                                    resultString = inputS.readLine();
                                }

                                if (resultString.equals("Response: 226 Closing data connection.")) {
                                    System.out.println("End of the retrieve function");
                                    serverInput.close();
                                    dataOutToFile.close();
                                    dataSocket.close();
                                } else {
                                    //print out of the error message from the server.
                                    System.out.println("Retrieve function did not end properly. Your file may not be complete.");
                                    serverInput.close();
                                    dataOutToFile.close();
                                    dataSocket.close();
                                }

//                            } else {
//                                System.out.println("Something went wrong with retrieve, server didn't respond correctly.");
//                            }
                        }
                    }

                    if (commandsAndParams[0].equals("STOR")) {
                        outputS.write("STOR " + commandsAndParams[1]);
                        outputS.write("\r\n"); //main control.
                        outputS.flush();

                        System.out.print("Store received");
                        //once the server has been warned and we get a signal back,
                        //then we put out the file itself on the new output stream
                        // of our new data connection, created on the server side?

                        String resultString = "";
                        while(resultString.equals("")) {
                            resultString = inputS.readLine(); //main control.
                        }

                        System.out.println(resultString);

                        if (resultString.equals("Response: 225 Data Connection Open.")) {

                            Socket dataSocket = new Socket(controlConnection.getInetAddress(), 3716);
                            DataOutputStream storeInput = new DataOutputStream(dataSocket.getOutputStream());

                            File wantedFile = new File(commandsAndParams[1]);
                            BufferedReader dataToServerFile = new BufferedReader(new FileReader(wantedFile));

                            String lastString = "ping";
                            while (true) {
                                try {
                                    lastString = dataToServerFile.readLine(); //read from server
                                    System.out.println("From File: " + lastString);
                                    if (!(lastString == null)) { //not getting an end of the file, might need to be actual null.
                                        storeInput.writeUTF(lastString); //shouldn't need my own \r\n.
                                        System.out.println("Wrote: " + lastString);
                                        storeInput.flush();
                                    } else {
                                        storeInput.writeUTF("EOF\r\n");
                                        storeInput.flush();
                                        break;
                                    }
                                } catch (Exception f) {
                                    System.out.println("store Exception " + f.toString());
                                    break; //end of file reached, so we are done.
                                }
                            }

                            //wait for the response.
                            resultString = "";
                            while (resultString.equals("")) {
                                resultString = inputS.readLine();
                            }

                            if (resultString.equals("Response: 226 Closing data connection.")) {
                                System.out.println("End of the retrieve function");
                                storeInput.close();
                                dataToServerFile.close();
                                dataSocket.close();
                            } else {
                                System.out.println("Retrieve function did not end properly. Your file may not be complete.");
                                storeInput.close();
                                dataToServerFile.close();
                                dataSocket.close();
                            }
                        }
                        else{
                            System.out.println("Something went wrong with Store, server didn't respond correctly.");
                        }

                    }

                    if(commandsAndParams[0].equals("PORT")){
                        outputS.write("PORT " + commandsAndParams[1]);
                        outputS.write("\r\n");
                        outputS.flush();
                    }
                } //end of if for handling two word/numbers commands
            }
            catch(Exception e){
                System.out.println("Something went wrong, did you input a " +
                        "proper command or proper number of parameters?");
                System.out.println(e.toString());
            }
            //back to the top of the while loop
        }
     //bottom of main.
    }

    static boolean connect(String ipAddr, int port) {
        try {
            controlConnection = new Socket(ipAddr, port); //or port 21
            inputS = new BufferedReader(new InputStreamReader(controlConnection.getInputStream()));
            outputS = new BufferedWriter(new OutputStreamWriter(controlConnection.getOutputStream()));

            //System.out.println("Connect received.");
            String response = inputS.readLine();
            //System.out.println("response received.");
            if(response.equals("Response: 220 Welcome to JFTP.")){
                return true;
            }
            else{
                return false;
            }

        }catch (Exception e) {
            System.out.println("Connection Exception. " + e.toString());
            return false;
        }

    }
//end of class bracket here.
}